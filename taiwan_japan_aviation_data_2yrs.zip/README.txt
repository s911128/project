台灣-日本航線數據分析專案
=================================

本壓縮檔包含過去兩年（2023-06-30 至 2025-06-30）的完整數據集：

📊 檔案說明：
1. taiwan_fuel_prices_2yrs.csv - 台灣中油JET A-1航空燃油價格（732筆/日）
2. usd_twd_exchange_rates_2yrs.csv - 美元對新台幣匯率（732筆/日）  
3. taiwan_japan_flight_prices_2yrs.csv - 台日航線機票價格（18,300筆）
4. taiwan_japan_aviation_analysis_2yrs.csv - 綜合分析數據（732筆/日）
5. monthly_summary_report_2yrs.csv - 月度摘要報告（25筆/月）

🎯 使用建議：
- Power BI導入：推薦使用 taiwan_japan_aviation_analysis_2yrs.csv
- 詳細分析：使用 taiwan_japan_flight_prices_2yrs.csv
- 趨勢圖表：使用 monthly_summary_report_2yrs.csv

📈 數據亮點：
- 時間範圍：732天完整數據
- 航線覆蓋：台北桃園/高雄小港 ↔ 東京/大阪
- 航空公司：中華航空、長榮航空、台灣虎航、酷航、捷星
- 季節性分析：夏季平均7,600元，冬季平均14,150元
- 匯率影響：新台幣兩年升值約8.5%
- 燃油趨勢：兩年下降約15%

資料產生時間：2025-07-01
編碼格式：UTF-8
